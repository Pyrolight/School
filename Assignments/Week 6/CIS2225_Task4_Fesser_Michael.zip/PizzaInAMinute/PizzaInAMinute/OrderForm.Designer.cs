﻿namespace PizzaInAMinute
{
    partial class orderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(orderForm));
            this.extrasGB = new System.Windows.Forms.GroupBox();
            this.chefWingsLabel = new System.Windows.Forms.Label();
            this.buffaloWingsLabal = new System.Windows.Forms.Label();
            this.hotWingsLabel = new System.Windows.Forms.Label();
            this.crazyBreadLabel = new System.Windows.Forms.Label();
            this.garlicFingersLabel = new System.Windows.Forms.Label();
            this.twistBreadLabel = new System.Windows.Forms.Label();
            this.chefWingsCB = new System.Windows.Forms.CheckBox();
            this.crazyBreadCB = new System.Windows.Forms.CheckBox();
            this.buffaloWingsCB = new System.Windows.Forms.CheckBox();
            this.hotWingsCB = new System.Windows.Forms.CheckBox();
            this.garlicFingersCB = new System.Windows.Forms.CheckBox();
            this.twistyBreadCB = new System.Windows.Forms.CheckBox();
            this.resetOrderButton = new System.Windows.Forms.Button();
            this.confimSelectionButton = new System.Windows.Forms.Button();
            this.pizzaGB = new System.Windows.Forms.GroupBox();
            this.chefCreationCombo = new System.Windows.Forms.ComboBox();
            this.americanCombo = new System.Windows.Forms.ComboBox();
            this.buildYourOwnCombo = new System.Windows.Forms.ComboBox();
            this.canadianCombo = new System.Windows.Forms.ComboBox();
            this.veggieCombo = new System.Windows.Forms.ComboBox();
            this.beefEaterCombo = new System.Windows.Forms.ComboBox();
            this.chickenLickenCombo = new System.Windows.Forms.ComboBox();
            this.hamAndPineappleCombo = new System.Windows.Forms.ComboBox();
            this.pizzaInfoLabel = new System.Windows.Forms.Label();
            this.buildYourOwnRB = new System.Windows.Forms.RadioButton();
            this.ChefCreationRB = new System.Windows.Forms.RadioButton();
            this.AmericanRB = new System.Windows.Forms.RadioButton();
            this.veggieRB = new System.Windows.Forms.RadioButton();
            this.CanadianRB = new System.Windows.Forms.RadioButton();
            this.beefEaterRB = new System.Windows.Forms.RadioButton();
            this.chickenLickenRB = new System.Windows.Forms.RadioButton();
            this.hamAndPinapleRB = new System.Windows.Forms.RadioButton();
            this.toppingsGB = new System.Windows.Forms.GroupBox();
            this.toppingsLabel = new System.Windows.Forms.Label();
            this.extraThinkCrustCB = new System.Windows.Forms.CheckBox();
            this.extraCheeseCB = new System.Windows.Forms.CheckBox();
            this.extraSauceCB = new System.Windows.Forms.CheckBox();
            this.tomatoesCB = new System.Windows.Forms.CheckBox();
            this.mushroomCB = new System.Windows.Forms.CheckBox();
            this.pineappleCB = new System.Windows.Forms.CheckBox();
            this.oliveCB = new System.Windows.Forms.CheckBox();
            this.greenPepperCB = new System.Windows.Forms.CheckBox();
            this.onionCB = new System.Windows.Forms.CheckBox();
            this.SalamiCB = new System.Windows.Forms.CheckBox();
            this.hamburgerCB = new System.Windows.Forms.CheckBox();
            this.sausageCB = new System.Windows.Forms.CheckBox();
            this.pepperoniCB = new System.Windows.Forms.CheckBox();
            this.hamCB = new System.Windows.Forms.CheckBox();
            this.crustGB = new System.Windows.Forms.GroupBox();
            this.crustTypeLabel = new System.Windows.Forms.Label();
            this.spinTheWheelLabel = new System.Windows.Forms.Label();
            this.sauceFilledLabel = new System.Windows.Forms.Label();
            this.spinTheWheelCrustRB = new System.Windows.Forms.RadioButton();
            this.sauceFilledCrustRB = new System.Windows.Forms.RadioButton();
            this.pretzelLabel = new System.Windows.Forms.Label();
            this.meatFilledLabel = new System.Windows.Forms.Label();
            this.cheeseFilledLabel = new System.Windows.Forms.Label();
            this.pretzelCrustRB = new System.Windows.Forms.RadioButton();
            this.cheeseFilledCrustRB = new System.Windows.Forms.RadioButton();
            this.regularCrustRB = new System.Windows.Forms.RadioButton();
            this.meatFilledCrustRB = new System.Windows.Forms.RadioButton();
            this.drinksGB = new System.Windows.Forms.GroupBox();
            this.rootBeerLabel = new System.Windows.Forms.Label();
            this.cokeLabel = new System.Windows.Forms.Label();
            this.pepsiLabel = new System.Windows.Forms.Label();
            this.rootBeerCB = new System.Windows.Forms.CheckBox();
            this.cokeCB = new System.Windows.Forms.CheckBox();
            this.pepsiCB = new System.Windows.Forms.CheckBox();
            this.contactInfoGB = new System.Windows.Forms.GroupBox();
            this.clearUserInfoButton = new System.Windows.Forms.Button();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.emailTB = new System.Windows.Forms.TextBox();
            this.phoneNumberMTB = new System.Windows.Forms.MaskedTextBox();
            this.emailLabel = new System.Windows.Forms.Label();
            this.phoneNumberLabel = new System.Windows.Forms.Label();
            this.addressLabel = new System.Windows.Forms.Label();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.addressTB = new System.Windows.Forms.TextBox();
            this.lastNameTB = new System.Windows.Forms.TextBox();
            this.firstNameTB = new System.Windows.Forms.TextBox();
            this.submitOrderButton = new System.Windows.Forms.Button();
            this.totalLabel = new System.Windows.Forms.Label();
            this.taxRateLabel = new System.Windows.Forms.Label();
            this.totalTB = new System.Windows.Forms.TextBox();
            this.taxTB = new System.Windows.Forms.TextBox();
            this.subTotalLabel = new System.Windows.Forms.Label();
            this.subtotalTB = new System.Windows.Forms.TextBox();
            this.header = new System.Windows.Forms.PictureBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.hiddenPadding = new System.Windows.Forms.TextBox();
            this.extrasGB.SuspendLayout();
            this.pizzaGB.SuspendLayout();
            this.toppingsGB.SuspendLayout();
            this.crustGB.SuspendLayout();
            this.drinksGB.SuspendLayout();
            this.contactInfoGB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.header)).BeginInit();
            this.SuspendLayout();
            // 
            // extrasGB
            // 
            this.extrasGB.Controls.Add(this.chefWingsLabel);
            this.extrasGB.Controls.Add(this.buffaloWingsLabal);
            this.extrasGB.Controls.Add(this.hotWingsLabel);
            this.extrasGB.Controls.Add(this.crazyBreadLabel);
            this.extrasGB.Controls.Add(this.garlicFingersLabel);
            this.extrasGB.Controls.Add(this.twistBreadLabel);
            this.extrasGB.Controls.Add(this.chefWingsCB);
            this.extrasGB.Controls.Add(this.crazyBreadCB);
            this.extrasGB.Controls.Add(this.buffaloWingsCB);
            this.extrasGB.Controls.Add(this.hotWingsCB);
            this.extrasGB.Controls.Add(this.garlicFingersCB);
            this.extrasGB.Controls.Add(this.twistyBreadCB);
            this.extrasGB.Location = new System.Drawing.Point(320, 353);
            this.extrasGB.Name = "extrasGB";
            this.extrasGB.Size = new System.Drawing.Size(239, 175);
            this.extrasGB.TabIndex = 21;
            this.extrasGB.TabStop = false;
            this.extrasGB.Text = "Extras";
            // 
            // chefWingsLabel
            // 
            this.chefWingsLabel.AutoSize = true;
            this.chefWingsLabel.Location = new System.Drawing.Point(127, 146);
            this.chefWingsLabel.Name = "chefWingsLabel";
            this.chefWingsLabel.Size = new System.Drawing.Size(34, 13);
            this.chefWingsLabel.TabIndex = 27;
            this.chefWingsLabel.Text = "$3.00";
            // 
            // buffaloWingsLabal
            // 
            this.buffaloWingsLabal.AutoSize = true;
            this.buffaloWingsLabal.Location = new System.Drawing.Point(127, 123);
            this.buffaloWingsLabal.Name = "buffaloWingsLabal";
            this.buffaloWingsLabal.Size = new System.Drawing.Size(34, 13);
            this.buffaloWingsLabal.TabIndex = 26;
            this.buffaloWingsLabal.Text = "$3.00";
            // 
            // hotWingsLabel
            // 
            this.hotWingsLabel.AutoSize = true;
            this.hotWingsLabel.Location = new System.Drawing.Point(127, 101);
            this.hotWingsLabel.Name = "hotWingsLabel";
            this.hotWingsLabel.Size = new System.Drawing.Size(34, 13);
            this.hotWingsLabel.TabIndex = 25;
            this.hotWingsLabel.Text = "$3.00";
            // 
            // crazyBreadLabel
            // 
            this.crazyBreadLabel.AutoSize = true;
            this.crazyBreadLabel.Location = new System.Drawing.Point(127, 77);
            this.crazyBreadLabel.Name = "crazyBreadLabel";
            this.crazyBreadLabel.Size = new System.Drawing.Size(34, 13);
            this.crazyBreadLabel.TabIndex = 24;
            this.crazyBreadLabel.Text = "$4.00";
            // 
            // garlicFingersLabel
            // 
            this.garlicFingersLabel.AutoSize = true;
            this.garlicFingersLabel.Location = new System.Drawing.Point(127, 55);
            this.garlicFingersLabel.Name = "garlicFingersLabel";
            this.garlicFingersLabel.Size = new System.Drawing.Size(34, 13);
            this.garlicFingersLabel.TabIndex = 23;
            this.garlicFingersLabel.Text = "$3.00";
            // 
            // twistBreadLabel
            // 
            this.twistBreadLabel.AutoSize = true;
            this.twistBreadLabel.Location = new System.Drawing.Point(127, 32);
            this.twistBreadLabel.Name = "twistBreadLabel";
            this.twistBreadLabel.Size = new System.Drawing.Size(34, 13);
            this.twistBreadLabel.TabIndex = 22;
            this.twistBreadLabel.Text = "$2.00";
            // 
            // chefWingsCB
            // 
            this.chefWingsCB.AutoSize = true;
            this.chefWingsCB.Location = new System.Drawing.Point(19, 146);
            this.chefWingsCB.Name = "chefWingsCB";
            this.chefWingsCB.Size = new System.Drawing.Size(88, 17);
            this.chefWingsCB.TabIndex = 21;
            this.chefWingsCB.Text = "Chef\'s Wings";
            this.chefWingsCB.UseVisualStyleBackColor = true;
            // 
            // crazyBreadCB
            // 
            this.crazyBreadCB.AutoSize = true;
            this.crazyBreadCB.Location = new System.Drawing.Point(19, 77);
            this.crazyBreadCB.Name = "crazyBreadCB";
            this.crazyBreadCB.Size = new System.Drawing.Size(83, 17);
            this.crazyBreadCB.TabIndex = 20;
            this.crazyBreadCB.Text = "Crazy Bread";
            this.crazyBreadCB.UseVisualStyleBackColor = true;
            // 
            // buffaloWingsCB
            // 
            this.buffaloWingsCB.AutoSize = true;
            this.buffaloWingsCB.Location = new System.Drawing.Point(19, 123);
            this.buffaloWingsCB.Name = "buffaloWingsCB";
            this.buffaloWingsCB.Size = new System.Drawing.Size(92, 17);
            this.buffaloWingsCB.TabIndex = 19;
            this.buffaloWingsCB.Text = "Buffalo Wings";
            this.buffaloWingsCB.UseVisualStyleBackColor = true;
            // 
            // hotWingsCB
            // 
            this.hotWingsCB.AutoSize = true;
            this.hotWingsCB.Location = new System.Drawing.Point(19, 100);
            this.hotWingsCB.Name = "hotWingsCB";
            this.hotWingsCB.Size = new System.Drawing.Size(76, 17);
            this.hotWingsCB.TabIndex = 18;
            this.hotWingsCB.Text = "Hot Wings";
            this.hotWingsCB.UseVisualStyleBackColor = true;
            // 
            // garlicFingersCB
            // 
            this.garlicFingersCB.AutoSize = true;
            this.garlicFingersCB.Location = new System.Drawing.Point(19, 55);
            this.garlicFingersCB.Name = "garlicFingersCB";
            this.garlicFingersCB.Size = new System.Drawing.Size(90, 17);
            this.garlicFingersCB.TabIndex = 17;
            this.garlicFingersCB.Text = "Garlic Fingers";
            this.garlicFingersCB.UseVisualStyleBackColor = true;
            // 
            // twistyBreadCB
            // 
            this.twistyBreadCB.AutoSize = true;
            this.twistyBreadCB.Location = new System.Drawing.Point(19, 32);
            this.twistyBreadCB.Name = "twistyBreadCB";
            this.twistyBreadCB.Size = new System.Drawing.Size(87, 17);
            this.twistyBreadCB.TabIndex = 16;
            this.twistyBreadCB.Text = "Twisty Bread";
            this.twistyBreadCB.UseVisualStyleBackColor = true;
            // 
            // resetOrderButton
            // 
            this.resetOrderButton.Location = new System.Drawing.Point(122, 657);
            this.resetOrderButton.Name = "resetOrderButton";
            this.resetOrderButton.Size = new System.Drawing.Size(75, 23);
            this.resetOrderButton.TabIndex = 20;
            this.resetOrderButton.Text = "Clear Order";
            this.resetOrderButton.UseVisualStyleBackColor = true;
            this.resetOrderButton.Click += new System.EventHandler(this.resetOrderButton_Click);
            // 
            // confimSelectionButton
            // 
            this.confimSelectionButton.Location = new System.Drawing.Point(15, 658);
            this.confimSelectionButton.Name = "confimSelectionButton";
            this.confimSelectionButton.Size = new System.Drawing.Size(101, 23);
            this.confimSelectionButton.TabIndex = 18;
            this.confimSelectionButton.Text = "Confirm Selection";
            this.confimSelectionButton.UseVisualStyleBackColor = true;
            this.confimSelectionButton.Click += new System.EventHandler(this.addItemsButton_Click);
            // 
            // pizzaGB
            // 
            this.pizzaGB.Controls.Add(this.chefCreationCombo);
            this.pizzaGB.Controls.Add(this.americanCombo);
            this.pizzaGB.Controls.Add(this.buildYourOwnCombo);
            this.pizzaGB.Controls.Add(this.canadianCombo);
            this.pizzaGB.Controls.Add(this.veggieCombo);
            this.pizzaGB.Controls.Add(this.beefEaterCombo);
            this.pizzaGB.Controls.Add(this.chickenLickenCombo);
            this.pizzaGB.Controls.Add(this.hamAndPineappleCombo);
            this.pizzaGB.Controls.Add(this.pizzaInfoLabel);
            this.pizzaGB.Controls.Add(this.buildYourOwnRB);
            this.pizzaGB.Controls.Add(this.ChefCreationRB);
            this.pizzaGB.Controls.Add(this.AmericanRB);
            this.pizzaGB.Controls.Add(this.veggieRB);
            this.pizzaGB.Controls.Add(this.CanadianRB);
            this.pizzaGB.Controls.Add(this.beefEaterRB);
            this.pizzaGB.Controls.Add(this.chickenLickenRB);
            this.pizzaGB.Controls.Add(this.hamAndPinapleRB);
            this.pizzaGB.Location = new System.Drawing.Point(12, 114);
            this.pizzaGB.Name = "pizzaGB";
            this.pizzaGB.Size = new System.Drawing.Size(280, 311);
            this.pizzaGB.TabIndex = 17;
            this.pizzaGB.TabStop = false;
            this.pizzaGB.Text = "Pizza";
            // 
            // chefCreationCombo
            // 
            this.chefCreationCombo.FormattingEnabled = true;
            this.chefCreationCombo.Items.AddRange(new object[] {
            "Small $14.95",
            "Medium $18.95",
            "Large $22.95"});
            this.chefCreationCombo.Location = new System.Drawing.Point(140, 196);
            this.chefCreationCombo.Name = "chefCreationCombo";
            this.chefCreationCombo.Size = new System.Drawing.Size(121, 21);
            this.chefCreationCombo.TabIndex = 20;
            // 
            // americanCombo
            // 
            this.americanCombo.FormattingEnabled = true;
            this.americanCombo.Items.AddRange(new object[] {
            "Small $13.95",
            "Medium $17.95",
            "Large $21.95"});
            this.americanCombo.Location = new System.Drawing.Point(140, 169);
            this.americanCombo.Name = "americanCombo";
            this.americanCombo.Size = new System.Drawing.Size(121, 21);
            this.americanCombo.TabIndex = 19;
            // 
            // buildYourOwnCombo
            // 
            this.buildYourOwnCombo.FormattingEnabled = true;
            this.buildYourOwnCombo.Items.AddRange(new object[] {
            "Small $7.95",
            "Medium $11.95",
            "Large $15.95"});
            this.buildYourOwnCombo.Location = new System.Drawing.Point(140, 223);
            this.buildYourOwnCombo.Name = "buildYourOwnCombo";
            this.buildYourOwnCombo.Size = new System.Drawing.Size(121, 21);
            this.buildYourOwnCombo.TabIndex = 18;
            // 
            // canadianCombo
            // 
            this.canadianCombo.FormattingEnabled = true;
            this.canadianCombo.Items.AddRange(new object[] {
            "Small $13.95",
            "Medium $17.95",
            "Large $21.95"});
            this.canadianCombo.Location = new System.Drawing.Point(140, 142);
            this.canadianCombo.Name = "canadianCombo";
            this.canadianCombo.Size = new System.Drawing.Size(121, 21);
            this.canadianCombo.TabIndex = 15;
            // 
            // veggieCombo
            // 
            this.veggieCombo.FormattingEnabled = true;
            this.veggieCombo.Items.AddRange(new object[] {
            "Small $10.95",
            "Medium $14.95",
            "Large $18.95"});
            this.veggieCombo.Location = new System.Drawing.Point(140, 115);
            this.veggieCombo.Name = "veggieCombo";
            this.veggieCombo.Size = new System.Drawing.Size(121, 21);
            this.veggieCombo.TabIndex = 14;
            // 
            // beefEaterCombo
            // 
            this.beefEaterCombo.FormattingEnabled = true;
            this.beefEaterCombo.Items.AddRange(new object[] {
            "Small $14.95",
            "Medium $18.95",
            "Large $22.95"});
            this.beefEaterCombo.Location = new System.Drawing.Point(140, 88);
            this.beefEaterCombo.Name = "beefEaterCombo";
            this.beefEaterCombo.Size = new System.Drawing.Size(121, 21);
            this.beefEaterCombo.TabIndex = 13;
            // 
            // chickenLickenCombo
            // 
            this.chickenLickenCombo.FormattingEnabled = true;
            this.chickenLickenCombo.Items.AddRange(new object[] {
            "Small $11.95",
            "Medium $15.95",
            "Large $19.95"});
            this.chickenLickenCombo.Location = new System.Drawing.Point(140, 61);
            this.chickenLickenCombo.Name = "chickenLickenCombo";
            this.chickenLickenCombo.Size = new System.Drawing.Size(121, 21);
            this.chickenLickenCombo.TabIndex = 12;
            // 
            // hamAndPineappleCombo
            // 
            this.hamAndPineappleCombo.FormattingEnabled = true;
            this.hamAndPineappleCombo.Items.AddRange(new object[] {
            "Small $10.95",
            "Medium $14.95",
            "Large $18.95"});
            this.hamAndPineappleCombo.Location = new System.Drawing.Point(140, 34);
            this.hamAndPineappleCombo.Name = "hamAndPineappleCombo";
            this.hamAndPineappleCombo.Size = new System.Drawing.Size(121, 21);
            this.hamAndPineappleCombo.TabIndex = 11;
            // 
            // pizzaInfoLabel
            // 
            this.pizzaInfoLabel.AutoSize = true;
            this.pizzaInfoLabel.Location = new System.Drawing.Point(11, 271);
            this.pizzaInfoLabel.Name = "pizzaInfoLabel";
            this.pizzaInfoLabel.Size = new System.Drawing.Size(247, 13);
            this.pizzaInfoLabel.TabIndex = 8;
            this.pizzaInfoLabel.Text = "All pizzas comes with the house sauce and cheese";
            // 
            // buildYourOwnRB
            // 
            this.buildYourOwnRB.AutoSize = true;
            this.buildYourOwnRB.Checked = true;
            this.buildYourOwnRB.Location = new System.Drawing.Point(16, 227);
            this.buildYourOwnRB.Name = "buildYourOwnRB";
            this.buildYourOwnRB.Size = new System.Drawing.Size(98, 17);
            this.buildYourOwnRB.TabIndex = 7;
            this.buildYourOwnRB.TabStop = true;
            this.buildYourOwnRB.Text = "Build Your Own";
            this.buildYourOwnRB.UseVisualStyleBackColor = true;
            // 
            // ChefCreationRB
            // 
            this.ChefCreationRB.AutoSize = true;
            this.ChefCreationRB.Location = new System.Drawing.Point(16, 200);
            this.ChefCreationRB.Name = "ChefCreationRB";
            this.ChefCreationRB.Size = new System.Drawing.Size(96, 17);
            this.ChefCreationRB.TabIndex = 6;
            this.ChefCreationRB.TabStop = true;
            this.ChefCreationRB.Text = "Chef\'s Creation";
            this.ChefCreationRB.UseVisualStyleBackColor = true;
            // 
            // AmericanRB
            // 
            this.AmericanRB.AutoSize = true;
            this.AmericanRB.Location = new System.Drawing.Point(16, 173);
            this.AmericanRB.Name = "AmericanRB";
            this.AmericanRB.Size = new System.Drawing.Size(69, 17);
            this.AmericanRB.TabIndex = 5;
            this.AmericanRB.TabStop = true;
            this.AmericanRB.Text = "American";
            this.AmericanRB.UseVisualStyleBackColor = true;
            // 
            // veggieRB
            // 
            this.veggieRB.AutoSize = true;
            this.veggieRB.Location = new System.Drawing.Point(16, 119);
            this.veggieRB.Name = "veggieRB";
            this.veggieRB.Size = new System.Drawing.Size(58, 17);
            this.veggieRB.TabIndex = 4;
            this.veggieRB.TabStop = true;
            this.veggieRB.Text = "Veggie";
            this.veggieRB.UseVisualStyleBackColor = true;
            // 
            // CanadianRB
            // 
            this.CanadianRB.AutoSize = true;
            this.CanadianRB.Location = new System.Drawing.Point(16, 146);
            this.CanadianRB.Name = "CanadianRB";
            this.CanadianRB.Size = new System.Drawing.Size(70, 17);
            this.CanadianRB.TabIndex = 3;
            this.CanadianRB.TabStop = true;
            this.CanadianRB.Text = "Canadian";
            this.CanadianRB.UseVisualStyleBackColor = true;
            // 
            // beefEaterRB
            // 
            this.beefEaterRB.AutoSize = true;
            this.beefEaterRB.Location = new System.Drawing.Point(16, 92);
            this.beefEaterRB.Name = "beefEaterRB";
            this.beefEaterRB.Size = new System.Drawing.Size(75, 17);
            this.beefEaterRB.TabIndex = 2;
            this.beefEaterRB.TabStop = true;
            this.beefEaterRB.Text = "Beef Eater";
            this.beefEaterRB.UseVisualStyleBackColor = true;
            // 
            // chickenLickenRB
            // 
            this.chickenLickenRB.AutoSize = true;
            this.chickenLickenRB.Location = new System.Drawing.Point(16, 65);
            this.chickenLickenRB.Name = "chickenLickenRB";
            this.chickenLickenRB.Size = new System.Drawing.Size(99, 17);
            this.chickenLickenRB.TabIndex = 1;
            this.chickenLickenRB.TabStop = true;
            this.chickenLickenRB.Text = "Chicken Licken";
            this.chickenLickenRB.UseVisualStyleBackColor = true;
            // 
            // hamAndPinapleRB
            // 
            this.hamAndPinapleRB.AutoSize = true;
            this.hamAndPinapleRB.Location = new System.Drawing.Point(16, 35);
            this.hamAndPinapleRB.Name = "hamAndPinapleRB";
            this.hamAndPinapleRB.Size = new System.Drawing.Size(118, 17);
            this.hamAndPinapleRB.TabIndex = 0;
            this.hamAndPinapleRB.TabStop = true;
            this.hamAndPinapleRB.Text = "Ham and Pineapple";
            this.hamAndPinapleRB.UseVisualStyleBackColor = true;
            // 
            // toppingsGB
            // 
            this.toppingsGB.Controls.Add(this.toppingsLabel);
            this.toppingsGB.Controls.Add(this.extraThinkCrustCB);
            this.toppingsGB.Controls.Add(this.extraCheeseCB);
            this.toppingsGB.Controls.Add(this.extraSauceCB);
            this.toppingsGB.Controls.Add(this.tomatoesCB);
            this.toppingsGB.Controls.Add(this.mushroomCB);
            this.toppingsGB.Controls.Add(this.pineappleCB);
            this.toppingsGB.Controls.Add(this.oliveCB);
            this.toppingsGB.Controls.Add(this.greenPepperCB);
            this.toppingsGB.Controls.Add(this.onionCB);
            this.toppingsGB.Controls.Add(this.SalamiCB);
            this.toppingsGB.Controls.Add(this.hamburgerCB);
            this.toppingsGB.Controls.Add(this.sausageCB);
            this.toppingsGB.Controls.Add(this.pepperoniCB);
            this.toppingsGB.Controls.Add(this.hamCB);
            this.toppingsGB.Location = new System.Drawing.Point(320, 114);
            this.toppingsGB.Name = "toppingsGB";
            this.toppingsGB.Size = new System.Drawing.Size(239, 231);
            this.toppingsGB.TabIndex = 15;
            this.toppingsGB.TabStop = false;
            this.toppingsGB.Text = "Toppings";
            // 
            // toppingsLabel
            // 
            this.toppingsLabel.AutoSize = true;
            this.toppingsLabel.Location = new System.Drawing.Point(41, 202);
            this.toppingsLabel.Name = "toppingsLabel";
            this.toppingsLabel.Size = new System.Drawing.Size(136, 13);
            this.toppingsLabel.TabIndex = 14;
            this.toppingsLabel.Text = "All toppings are $1.50 each";
            // 
            // extraThinkCrustCB
            // 
            this.extraThinkCrustCB.AutoSize = true;
            this.extraThinkCrustCB.Location = new System.Drawing.Point(130, 173);
            this.extraThinkCrustCB.Name = "extraThinkCrustCB";
            this.extraThinkCrustCB.Size = new System.Drawing.Size(107, 17);
            this.extraThinkCrustCB.TabIndex = 13;
            this.extraThinkCrustCB.Text = "Extra Think Crust";
            this.extraThinkCrustCB.UseVisualStyleBackColor = true;
            // 
            // extraCheeseCB
            // 
            this.extraCheeseCB.AutoSize = true;
            this.extraCheeseCB.Location = new System.Drawing.Point(130, 150);
            this.extraCheeseCB.Name = "extraCheeseCB";
            this.extraCheeseCB.Size = new System.Drawing.Size(89, 17);
            this.extraCheeseCB.TabIndex = 12;
            this.extraCheeseCB.Text = "Extra Cheese";
            this.extraCheeseCB.UseVisualStyleBackColor = true;
            // 
            // extraSauceCB
            // 
            this.extraSauceCB.AutoSize = true;
            this.extraSauceCB.Location = new System.Drawing.Point(130, 127);
            this.extraSauceCB.Name = "extraSauceCB";
            this.extraSauceCB.Size = new System.Drawing.Size(84, 17);
            this.extraSauceCB.TabIndex = 11;
            this.extraSauceCB.Text = "Extra Sauce";
            this.extraSauceCB.UseVisualStyleBackColor = true;
            // 
            // tomatoesCB
            // 
            this.tomatoesCB.AutoSize = true;
            this.tomatoesCB.Location = new System.Drawing.Point(130, 104);
            this.tomatoesCB.Name = "tomatoesCB";
            this.tomatoesCB.Size = new System.Drawing.Size(73, 17);
            this.tomatoesCB.TabIndex = 10;
            this.tomatoesCB.Text = "Tomatoes";
            this.tomatoesCB.UseVisualStyleBackColor = true;
            // 
            // mushroomCB
            // 
            this.mushroomCB.AutoSize = true;
            this.mushroomCB.Location = new System.Drawing.Point(130, 81);
            this.mushroomCB.Name = "mushroomCB";
            this.mushroomCB.Size = new System.Drawing.Size(80, 17);
            this.mushroomCB.TabIndex = 9;
            this.mushroomCB.Text = "Mushrooms";
            this.mushroomCB.UseVisualStyleBackColor = true;
            // 
            // pineappleCB
            // 
            this.pineappleCB.AutoSize = true;
            this.pineappleCB.Location = new System.Drawing.Point(130, 58);
            this.pineappleCB.Name = "pineappleCB";
            this.pineappleCB.Size = new System.Drawing.Size(73, 17);
            this.pineappleCB.TabIndex = 8;
            this.pineappleCB.Text = "Pineapple";
            this.pineappleCB.UseVisualStyleBackColor = true;
            // 
            // oliveCB
            // 
            this.oliveCB.AutoSize = true;
            this.oliveCB.Location = new System.Drawing.Point(130, 35);
            this.oliveCB.Name = "oliveCB";
            this.oliveCB.Size = new System.Drawing.Size(55, 17);
            this.oliveCB.TabIndex = 7;
            this.oliveCB.Text = "Olives";
            this.oliveCB.UseVisualStyleBackColor = true;
            // 
            // greenPepperCB
            // 
            this.greenPepperCB.AutoSize = true;
            this.greenPepperCB.Location = new System.Drawing.Point(19, 173);
            this.greenPepperCB.Name = "greenPepperCB";
            this.greenPepperCB.Size = new System.Drawing.Size(92, 17);
            this.greenPepperCB.TabIndex = 6;
            this.greenPepperCB.Text = "Green Pepper";
            this.greenPepperCB.UseVisualStyleBackColor = true;
            // 
            // onionCB
            // 
            this.onionCB.AutoSize = true;
            this.onionCB.Location = new System.Drawing.Point(19, 150);
            this.onionCB.Name = "onionCB";
            this.onionCB.Size = new System.Drawing.Size(54, 17);
            this.onionCB.TabIndex = 5;
            this.onionCB.Text = "Onion";
            this.onionCB.UseVisualStyleBackColor = true;
            // 
            // SalamiCB
            // 
            this.SalamiCB.AutoSize = true;
            this.SalamiCB.Location = new System.Drawing.Point(19, 127);
            this.SalamiCB.Name = "SalamiCB";
            this.SalamiCB.Size = new System.Drawing.Size(57, 17);
            this.SalamiCB.TabIndex = 4;
            this.SalamiCB.Text = "Salami";
            this.SalamiCB.UseVisualStyleBackColor = true;
            // 
            // hamburgerCB
            // 
            this.hamburgerCB.AutoSize = true;
            this.hamburgerCB.Location = new System.Drawing.Point(19, 104);
            this.hamburgerCB.Name = "hamburgerCB";
            this.hamburgerCB.Size = new System.Drawing.Size(78, 17);
            this.hamburgerCB.TabIndex = 3;
            this.hamburgerCB.Text = "Hamburger";
            this.hamburgerCB.UseVisualStyleBackColor = true;
            // 
            // sausageCB
            // 
            this.sausageCB.AutoSize = true;
            this.sausageCB.Location = new System.Drawing.Point(19, 81);
            this.sausageCB.Name = "sausageCB";
            this.sausageCB.Size = new System.Drawing.Size(68, 17);
            this.sausageCB.TabIndex = 2;
            this.sausageCB.Text = "Sausage";
            this.sausageCB.UseVisualStyleBackColor = true;
            // 
            // pepperoniCB
            // 
            this.pepperoniCB.AutoSize = true;
            this.pepperoniCB.Location = new System.Drawing.Point(19, 58);
            this.pepperoniCB.Name = "pepperoniCB";
            this.pepperoniCB.Size = new System.Drawing.Size(74, 17);
            this.pepperoniCB.TabIndex = 1;
            this.pepperoniCB.Text = "Pepperoni";
            this.pepperoniCB.UseVisualStyleBackColor = true;
            // 
            // hamCB
            // 
            this.hamCB.AutoSize = true;
            this.hamCB.Location = new System.Drawing.Point(19, 35);
            this.hamCB.Name = "hamCB";
            this.hamCB.Size = new System.Drawing.Size(48, 17);
            this.hamCB.TabIndex = 0;
            this.hamCB.Text = "Ham";
            this.hamCB.UseVisualStyleBackColor = true;
            // 
            // crustGB
            // 
            this.crustGB.Controls.Add(this.crustTypeLabel);
            this.crustGB.Controls.Add(this.spinTheWheelLabel);
            this.crustGB.Controls.Add(this.sauceFilledLabel);
            this.crustGB.Controls.Add(this.spinTheWheelCrustRB);
            this.crustGB.Controls.Add(this.sauceFilledCrustRB);
            this.crustGB.Controls.Add(this.pretzelLabel);
            this.crustGB.Controls.Add(this.meatFilledLabel);
            this.crustGB.Controls.Add(this.cheeseFilledLabel);
            this.crustGB.Controls.Add(this.pretzelCrustRB);
            this.crustGB.Controls.Add(this.cheeseFilledCrustRB);
            this.crustGB.Controls.Add(this.regularCrustRB);
            this.crustGB.Controls.Add(this.meatFilledCrustRB);
            this.crustGB.Location = new System.Drawing.Point(12, 442);
            this.crustGB.Name = "crustGB";
            this.crustGB.Size = new System.Drawing.Size(280, 199);
            this.crustGB.TabIndex = 16;
            this.crustGB.TabStop = false;
            this.crustGB.Text = "Crust Type";
            // 
            // crustTypeLabel
            // 
            this.crustTypeLabel.AutoSize = true;
            this.crustTypeLabel.Location = new System.Drawing.Point(13, 171);
            this.crustTypeLabel.Name = "crustTypeLabel";
            this.crustTypeLabel.Size = new System.Drawing.Size(202, 13);
            this.crustTypeLabel.TabIndex = 13;
            this.crustTypeLabel.Text = "Spin the wheel can have any topping in it";
            // 
            // spinTheWheelLabel
            // 
            this.spinTheWheelLabel.AutoSize = true;
            this.spinTheWheelLabel.Location = new System.Drawing.Point(137, 150);
            this.spinTheWheelLabel.Name = "spinTheWheelLabel";
            this.spinTheWheelLabel.Size = new System.Drawing.Size(60, 13);
            this.spinTheWheelLabel.TabIndex = 12;
            this.spinTheWheelLabel.Text = "$3.00 extra";
            // 
            // sauceFilledLabel
            // 
            this.sauceFilledLabel.AutoSize = true;
            this.sauceFilledLabel.Location = new System.Drawing.Point(137, 125);
            this.sauceFilledLabel.Name = "sauceFilledLabel";
            this.sauceFilledLabel.Size = new System.Drawing.Size(60, 13);
            this.sauceFilledLabel.TabIndex = 11;
            this.sauceFilledLabel.Text = "$2.00 extra";
            // 
            // spinTheWheelCrustRB
            // 
            this.spinTheWheelCrustRB.AutoSize = true;
            this.spinTheWheelCrustRB.Location = new System.Drawing.Point(16, 146);
            this.spinTheWheelCrustRB.Name = "spinTheWheelCrustRB";
            this.spinTheWheelCrustRB.Size = new System.Drawing.Size(102, 17);
            this.spinTheWheelCrustRB.TabIndex = 10;
            this.spinTheWheelCrustRB.Text = "Spin The Wheel";
            this.spinTheWheelCrustRB.UseVisualStyleBackColor = true;
            // 
            // sauceFilledCrustRB
            // 
            this.sauceFilledCrustRB.AutoSize = true;
            this.sauceFilledCrustRB.Location = new System.Drawing.Point(16, 123);
            this.sauceFilledCrustRB.Name = "sauceFilledCrustRB";
            this.sauceFilledCrustRB.Size = new System.Drawing.Size(83, 17);
            this.sauceFilledCrustRB.TabIndex = 9;
            this.sauceFilledCrustRB.Text = "Sauce Filled";
            this.sauceFilledCrustRB.UseVisualStyleBackColor = true;
            // 
            // pretzelLabel
            // 
            this.pretzelLabel.AutoSize = true;
            this.pretzelLabel.Location = new System.Drawing.Point(137, 79);
            this.pretzelLabel.Name = "pretzelLabel";
            this.pretzelLabel.Size = new System.Drawing.Size(60, 13);
            this.pretzelLabel.TabIndex = 8;
            this.pretzelLabel.Text = "$2.50 extra";
            // 
            // meatFilledLabel
            // 
            this.meatFilledLabel.AutoSize = true;
            this.meatFilledLabel.Location = new System.Drawing.Point(137, 101);
            this.meatFilledLabel.Name = "meatFilledLabel";
            this.meatFilledLabel.Size = new System.Drawing.Size(60, 13);
            this.meatFilledLabel.TabIndex = 7;
            this.meatFilledLabel.Text = "$3.00 extra";
            // 
            // cheeseFilledLabel
            // 
            this.cheeseFilledLabel.AutoSize = true;
            this.cheeseFilledLabel.Location = new System.Drawing.Point(137, 56);
            this.cheeseFilledLabel.Name = "cheeseFilledLabel";
            this.cheeseFilledLabel.Size = new System.Drawing.Size(60, 13);
            this.cheeseFilledLabel.TabIndex = 6;
            this.cheeseFilledLabel.Text = "$2.00 extra";
            // 
            // pretzelCrustRB
            // 
            this.pretzelCrustRB.AutoSize = true;
            this.pretzelCrustRB.Location = new System.Drawing.Point(16, 73);
            this.pretzelCrustRB.Name = "pretzelCrustRB";
            this.pretzelCrustRB.Size = new System.Drawing.Size(57, 17);
            this.pretzelCrustRB.TabIndex = 4;
            this.pretzelCrustRB.Text = "Pretzel";
            this.pretzelCrustRB.UseVisualStyleBackColor = true;
            // 
            // cheeseFilledCrustRB
            // 
            this.cheeseFilledCrustRB.AutoSize = true;
            this.cheeseFilledCrustRB.Location = new System.Drawing.Point(16, 52);
            this.cheeseFilledCrustRB.Name = "cheeseFilledCrustRB";
            this.cheeseFilledCrustRB.Size = new System.Drawing.Size(88, 17);
            this.cheeseFilledCrustRB.TabIndex = 2;
            this.cheeseFilledCrustRB.Text = "Cheese Filled";
            this.cheeseFilledCrustRB.UseVisualStyleBackColor = true;
            // 
            // regularCrustRB
            // 
            this.regularCrustRB.AutoSize = true;
            this.regularCrustRB.Checked = true;
            this.regularCrustRB.Location = new System.Drawing.Point(16, 30);
            this.regularCrustRB.Name = "regularCrustRB";
            this.regularCrustRB.Size = new System.Drawing.Size(62, 17);
            this.regularCrustRB.TabIndex = 1;
            this.regularCrustRB.TabStop = true;
            this.regularCrustRB.Text = "Regular";
            this.regularCrustRB.UseVisualStyleBackColor = true;
            // 
            // meatFilledCrustRB
            // 
            this.meatFilledCrustRB.AutoSize = true;
            this.meatFilledCrustRB.Location = new System.Drawing.Point(16, 97);
            this.meatFilledCrustRB.Name = "meatFilledCrustRB";
            this.meatFilledCrustRB.Size = new System.Drawing.Size(76, 17);
            this.meatFilledCrustRB.TabIndex = 3;
            this.meatFilledCrustRB.Text = "Meat Filled";
            this.meatFilledCrustRB.UseVisualStyleBackColor = true;
            // 
            // drinksGB
            // 
            this.drinksGB.Controls.Add(this.rootBeerLabel);
            this.drinksGB.Controls.Add(this.cokeLabel);
            this.drinksGB.Controls.Add(this.pepsiLabel);
            this.drinksGB.Controls.Add(this.rootBeerCB);
            this.drinksGB.Controls.Add(this.cokeCB);
            this.drinksGB.Controls.Add(this.pepsiCB);
            this.drinksGB.Location = new System.Drawing.Point(320, 537);
            this.drinksGB.Name = "drinksGB";
            this.drinksGB.Size = new System.Drawing.Size(239, 104);
            this.drinksGB.TabIndex = 40;
            this.drinksGB.TabStop = false;
            this.drinksGB.Text = "Drinks";
            // 
            // rootBeerLabel
            // 
            this.rootBeerLabel.AutoSize = true;
            this.rootBeerLabel.Location = new System.Drawing.Point(127, 72);
            this.rootBeerLabel.Name = "rootBeerLabel";
            this.rootBeerLabel.Size = new System.Drawing.Size(34, 13);
            this.rootBeerLabel.TabIndex = 51;
            this.rootBeerLabel.Text = "$2.00";
            // 
            // cokeLabel
            // 
            this.cokeLabel.AutoSize = true;
            this.cokeLabel.Location = new System.Drawing.Point(127, 49);
            this.cokeLabel.Name = "cokeLabel";
            this.cokeLabel.Size = new System.Drawing.Size(34, 13);
            this.cokeLabel.TabIndex = 50;
            this.cokeLabel.Text = "$2.00";
            // 
            // pepsiLabel
            // 
            this.pepsiLabel.AutoSize = true;
            this.pepsiLabel.Location = new System.Drawing.Point(127, 26);
            this.pepsiLabel.Name = "pepsiLabel";
            this.pepsiLabel.Size = new System.Drawing.Size(34, 13);
            this.pepsiLabel.TabIndex = 49;
            this.pepsiLabel.Text = "$2.00";
            // 
            // rootBeerCB
            // 
            this.rootBeerCB.AutoSize = true;
            this.rootBeerCB.Location = new System.Drawing.Point(19, 72);
            this.rootBeerCB.Name = "rootBeerCB";
            this.rootBeerCB.Size = new System.Drawing.Size(106, 17);
            this.rootBeerCB.TabIndex = 48;
            this.rootBeerCB.Text = "2 Litre Root Beer";
            this.rootBeerCB.UseVisualStyleBackColor = true;
            // 
            // cokeCB
            // 
            this.cokeCB.AutoSize = true;
            this.cokeCB.Location = new System.Drawing.Point(19, 49);
            this.cokeCB.Name = "cokeCB";
            this.cokeCB.Size = new System.Drawing.Size(83, 17);
            this.cokeCB.TabIndex = 47;
            this.cokeCB.Text = "2 Litre Coke";
            this.cokeCB.UseVisualStyleBackColor = true;
            // 
            // pepsiCB
            // 
            this.pepsiCB.AutoSize = true;
            this.pepsiCB.Location = new System.Drawing.Point(19, 26);
            this.pepsiCB.Name = "pepsiCB";
            this.pepsiCB.Size = new System.Drawing.Size(84, 17);
            this.pepsiCB.TabIndex = 46;
            this.pepsiCB.Text = "2 Litre Pepsi";
            this.pepsiCB.UseVisualStyleBackColor = true;
            // 
            // contactInfoGB
            // 
            this.contactInfoGB.Controls.Add(this.clearUserInfoButton);
            this.contactInfoGB.Controls.Add(this.lastNameLabel);
            this.contactInfoGB.Controls.Add(this.emailTB);
            this.contactInfoGB.Controls.Add(this.phoneNumberMTB);
            this.contactInfoGB.Controls.Add(this.emailLabel);
            this.contactInfoGB.Controls.Add(this.phoneNumberLabel);
            this.contactInfoGB.Controls.Add(this.addressLabel);
            this.contactInfoGB.Controls.Add(this.firstNameLabel);
            this.contactInfoGB.Controls.Add(this.addressTB);
            this.contactInfoGB.Controls.Add(this.lastNameTB);
            this.contactInfoGB.Controls.Add(this.firstNameTB);
            this.contactInfoGB.Location = new System.Drawing.Point(12, 750);
            this.contactInfoGB.Name = "contactInfoGB";
            this.contactInfoGB.Size = new System.Drawing.Size(545, 174);
            this.contactInfoGB.TabIndex = 48;
            this.contactInfoGB.TabStop = false;
            this.contactInfoGB.Text = "Contact Information";
            // 
            // clearUserInfoButton
            // 
            this.clearUserInfoButton.Location = new System.Drawing.Point(426, 132);
            this.clearUserInfoButton.Name = "clearUserInfoButton";
            this.clearUserInfoButton.Size = new System.Drawing.Size(101, 23);
            this.clearUserInfoButton.TabIndex = 58;
            this.clearUserInfoButton.Text = "Clear Information";
            this.clearUserInfoButton.UseVisualStyleBackColor = true;
            this.clearUserInfoButton.Click += new System.EventHandler(this.clearUserInfoButton_Click);
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(11, 56);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(58, 13);
            this.lastNameLabel.TabIndex = 57;
            this.lastNameLabel.Text = "Last Name";
            // 
            // emailTB
            // 
            this.emailTB.Location = new System.Drawing.Point(157, 131);
            this.emailTB.Name = "emailTB";
            this.emailTB.Size = new System.Drawing.Size(161, 20);
            this.emailTB.TabIndex = 56;
            // 
            // phoneNumberMTB
            // 
            this.phoneNumberMTB.Location = new System.Drawing.Point(157, 108);
            this.phoneNumberMTB.Mask = "(999) 000-0000";
            this.phoneNumberMTB.Name = "phoneNumberMTB";
            this.phoneNumberMTB.Size = new System.Drawing.Size(80, 20);
            this.phoneNumberMTB.TabIndex = 55;
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(11, 134);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(32, 13);
            this.emailLabel.TabIndex = 54;
            this.emailLabel.Text = "Email";
            // 
            // phoneNumberLabel
            // 
            this.phoneNumberLabel.AutoSize = true;
            this.phoneNumberLabel.Location = new System.Drawing.Point(11, 108);
            this.phoneNumberLabel.Name = "phoneNumberLabel";
            this.phoneNumberLabel.Size = new System.Drawing.Size(78, 13);
            this.phoneNumberLabel.TabIndex = 53;
            this.phoneNumberLabel.Text = "Phone Number";
            // 
            // addressLabel
            // 
            this.addressLabel.AutoSize = true;
            this.addressLabel.Location = new System.Drawing.Point(11, 82);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(45, 13);
            this.addressLabel.TabIndex = 52;
            this.addressLabel.Text = "Address";
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(11, 30);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(57, 13);
            this.firstNameLabel.TabIndex = 51;
            this.firstNameLabel.Text = "First Name";
            // 
            // addressTB
            // 
            this.addressTB.Location = new System.Drawing.Point(157, 82);
            this.addressTB.Name = "addressTB";
            this.addressTB.Size = new System.Drawing.Size(161, 20);
            this.addressTB.TabIndex = 50;
            // 
            // lastNameTB
            // 
            this.lastNameTB.Location = new System.Drawing.Point(157, 56);
            this.lastNameTB.Name = "lastNameTB";
            this.lastNameTB.Size = new System.Drawing.Size(161, 20);
            this.lastNameTB.TabIndex = 49;
            // 
            // firstNameTB
            // 
            this.firstNameTB.Location = new System.Drawing.Point(157, 30);
            this.firstNameTB.Name = "firstNameTB";
            this.firstNameTB.Size = new System.Drawing.Size(161, 20);
            this.firstNameTB.TabIndex = 48;
            // 
            // submitOrderButton
            // 
            this.submitOrderButton.Location = new System.Drawing.Point(15, 940);
            this.submitOrderButton.Name = "submitOrderButton";
            this.submitOrderButton.Size = new System.Drawing.Size(85, 23);
            this.submitOrderButton.TabIndex = 49;
            this.submitOrderButton.Text = "Submit Order";
            this.submitOrderButton.UseVisualStyleBackColor = true;
            this.submitOrderButton.Click += new System.EventHandler(this.submitOrderButton_Click);
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Location = new System.Drawing.Point(316, 712);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(31, 13);
            this.totalLabel.TabIndex = 59;
            this.totalLabel.Text = "Total";
            // 
            // taxRateLabel
            // 
            this.taxRateLabel.AutoSize = true;
            this.taxRateLabel.Location = new System.Drawing.Point(316, 686);
            this.taxRateLabel.Name = "taxRateLabel";
            this.taxRateLabel.Size = new System.Drawing.Size(51, 13);
            this.taxRateLabel.TabIndex = 58;
            this.taxRateLabel.Text = "Tax Rate";
            // 
            // totalTB
            // 
            this.totalTB.BackColor = System.Drawing.SystemColors.Window;
            this.totalTB.Location = new System.Drawing.Point(373, 712);
            this.totalTB.Name = "totalTB";
            this.totalTB.ReadOnly = true;
            this.totalTB.Size = new System.Drawing.Size(100, 20);
            this.totalTB.TabIndex = 57;
            // 
            // taxTB
            // 
            this.taxTB.BackColor = System.Drawing.SystemColors.Window;
            this.taxTB.Location = new System.Drawing.Point(373, 686);
            this.taxTB.Name = "taxTB";
            this.taxTB.ReadOnly = true;
            this.taxTB.Size = new System.Drawing.Size(34, 20);
            this.taxTB.TabIndex = 56;
            // 
            // subTotalLabel
            // 
            this.subTotalLabel.AutoSize = true;
            this.subTotalLabel.Location = new System.Drawing.Point(317, 663);
            this.subTotalLabel.Name = "subTotalLabel";
            this.subTotalLabel.Size = new System.Drawing.Size(50, 13);
            this.subTotalLabel.TabIndex = 55;
            this.subTotalLabel.Text = "SubTotal";
            // 
            // subtotalTB
            // 
            this.subtotalTB.BackColor = System.Drawing.SystemColors.Window;
            this.subtotalTB.Location = new System.Drawing.Point(373, 660);
            this.subtotalTB.Name = "subtotalTB";
            this.subtotalTB.ReadOnly = true;
            this.subtotalTB.Size = new System.Drawing.Size(100, 20);
            this.subtotalTB.TabIndex = 54;
            // 
            // header
            // 
            this.header.Image = ((System.Drawing.Image)(resources.GetObject("header.Image")));
            this.header.Location = new System.Drawing.Point(12, 12);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(576, 96);
            this.header.TabIndex = 60;
            this.header.TabStop = false;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(203, 657);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 61;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // hiddenPadding
            // 
            this.hiddenPadding.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.hiddenPadding.Location = new System.Drawing.Point(209, 972);
            this.hiddenPadding.Name = "hiddenPadding";
            this.hiddenPadding.ReadOnly = true;
            this.hiddenPadding.Size = new System.Drawing.Size(100, 13);
            this.hiddenPadding.TabIndex = 62;
            // 
            // orderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(601, 882);
            this.Controls.Add(this.hiddenPadding);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.header);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.taxRateLabel);
            this.Controls.Add(this.totalTB);
            this.Controls.Add(this.taxTB);
            this.Controls.Add(this.subTotalLabel);
            this.Controls.Add(this.subtotalTB);
            this.Controls.Add(this.submitOrderButton);
            this.Controls.Add(this.contactInfoGB);
            this.Controls.Add(this.drinksGB);
            this.Controls.Add(this.extrasGB);
            this.Controls.Add(this.resetOrderButton);
            this.Controls.Add(this.confimSelectionButton);
            this.Controls.Add(this.pizzaGB);
            this.Controls.Add(this.toppingsGB);
            this.Controls.Add(this.crustGB);
            this.Name = "orderForm";
            this.Text = "Pizza In A Minute";
            this.extrasGB.ResumeLayout(false);
            this.extrasGB.PerformLayout();
            this.pizzaGB.ResumeLayout(false);
            this.pizzaGB.PerformLayout();
            this.toppingsGB.ResumeLayout(false);
            this.toppingsGB.PerformLayout();
            this.crustGB.ResumeLayout(false);
            this.crustGB.PerformLayout();
            this.drinksGB.ResumeLayout(false);
            this.drinksGB.PerformLayout();
            this.contactInfoGB.ResumeLayout(false);
            this.contactInfoGB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.header)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox extrasGB;
        private System.Windows.Forms.Label chefWingsLabel;
        private System.Windows.Forms.Label buffaloWingsLabal;
        private System.Windows.Forms.Label hotWingsLabel;
        private System.Windows.Forms.Label crazyBreadLabel;
        private System.Windows.Forms.Label garlicFingersLabel;
        private System.Windows.Forms.Label twistBreadLabel;
        private System.Windows.Forms.CheckBox chefWingsCB;
        private System.Windows.Forms.CheckBox crazyBreadCB;
        private System.Windows.Forms.CheckBox buffaloWingsCB;
        private System.Windows.Forms.CheckBox hotWingsCB;
        private System.Windows.Forms.CheckBox garlicFingersCB;
        private System.Windows.Forms.CheckBox twistyBreadCB;
        private System.Windows.Forms.Button resetOrderButton;
        private System.Windows.Forms.Button confimSelectionButton;
        private System.Windows.Forms.GroupBox pizzaGB;
        private System.Windows.Forms.ComboBox chefCreationCombo;
        private System.Windows.Forms.ComboBox americanCombo;
        private System.Windows.Forms.ComboBox buildYourOwnCombo;
        private System.Windows.Forms.ComboBox canadianCombo;
        private System.Windows.Forms.ComboBox veggieCombo;
        private System.Windows.Forms.ComboBox beefEaterCombo;
        private System.Windows.Forms.ComboBox chickenLickenCombo;
        private System.Windows.Forms.ComboBox hamAndPineappleCombo;
        private System.Windows.Forms.Label pizzaInfoLabel;
        private System.Windows.Forms.RadioButton buildYourOwnRB;
        private System.Windows.Forms.RadioButton ChefCreationRB;
        private System.Windows.Forms.RadioButton AmericanRB;
        private System.Windows.Forms.RadioButton veggieRB;
        private System.Windows.Forms.RadioButton CanadianRB;
        private System.Windows.Forms.RadioButton beefEaterRB;
        private System.Windows.Forms.RadioButton chickenLickenRB;
        private System.Windows.Forms.RadioButton hamAndPinapleRB;
        private System.Windows.Forms.GroupBox toppingsGB;
        private System.Windows.Forms.Label toppingsLabel;
        private System.Windows.Forms.CheckBox extraThinkCrustCB;
        private System.Windows.Forms.CheckBox extraCheeseCB;
        private System.Windows.Forms.CheckBox extraSauceCB;
        private System.Windows.Forms.CheckBox tomatoesCB;
        private System.Windows.Forms.CheckBox mushroomCB;
        private System.Windows.Forms.CheckBox pineappleCB;
        private System.Windows.Forms.CheckBox oliveCB;
        private System.Windows.Forms.CheckBox greenPepperCB;
        private System.Windows.Forms.CheckBox onionCB;
        private System.Windows.Forms.CheckBox SalamiCB;
        private System.Windows.Forms.CheckBox hamburgerCB;
        private System.Windows.Forms.CheckBox sausageCB;
        private System.Windows.Forms.CheckBox pepperoniCB;
        private System.Windows.Forms.CheckBox hamCB;
        private System.Windows.Forms.GroupBox crustGB;
        private System.Windows.Forms.Label pretzelLabel;
        private System.Windows.Forms.Label meatFilledLabel;
        private System.Windows.Forms.Label cheeseFilledLabel;
        private System.Windows.Forms.RadioButton pretzelCrustRB;
        private System.Windows.Forms.RadioButton cheeseFilledCrustRB;
        private System.Windows.Forms.RadioButton regularCrustRB;
        private System.Windows.Forms.RadioButton meatFilledCrustRB;
        private System.Windows.Forms.RadioButton spinTheWheelCrustRB;
        private System.Windows.Forms.RadioButton sauceFilledCrustRB;
        private System.Windows.Forms.Label spinTheWheelLabel;
        private System.Windows.Forms.Label sauceFilledLabel;
        private System.Windows.Forms.GroupBox drinksGB;
        private System.Windows.Forms.Label rootBeerLabel;
        private System.Windows.Forms.Label cokeLabel;
        private System.Windows.Forms.Label pepsiLabel;
        private System.Windows.Forms.CheckBox rootBeerCB;
        private System.Windows.Forms.CheckBox cokeCB;
        private System.Windows.Forms.CheckBox pepsiCB;
        private System.Windows.Forms.Label crustTypeLabel;
        private System.Windows.Forms.GroupBox contactInfoGB;
        private System.Windows.Forms.MaskedTextBox phoneNumberMTB;
        private System.Windows.Forms.Label emailLabel;
        private System.Windows.Forms.Label phoneNumberLabel;
        private System.Windows.Forms.Label addressLabel;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.TextBox addressTB;
        private System.Windows.Forms.TextBox lastNameTB;
        private System.Windows.Forms.TextBox firstNameTB;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.TextBox emailTB;
        private System.Windows.Forms.Button submitOrderButton;
        private System.Windows.Forms.Button clearUserInfoButton;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Label taxRateLabel;
        private System.Windows.Forms.TextBox totalTB;
        private System.Windows.Forms.TextBox taxTB;
        private System.Windows.Forms.Label subTotalLabel;
        private System.Windows.Forms.TextBox subtotalTB;
        private System.Windows.Forms.PictureBox header;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox hiddenPadding;

    }
}

